Atom panel
==========
A custom panel for gnome-shell. This panel is part of the Atom Extension Set designed for Ozon OS.

### Compatibility

This application is written and tested on Gnome Shell 3.12, though it may be compatible with Gnome Shell 3.10.

### Installation

To install this extension, run

`make install` 

### License 

This project is licensed with GPL version 3 and later.
